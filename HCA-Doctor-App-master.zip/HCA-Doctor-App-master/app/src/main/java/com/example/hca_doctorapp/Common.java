package com.example.hca_doctorapp;

public class Common {
    public static String username="";
    public static String useremail="";
    public static String server_url = "https://jaychikki.com/HCA/doctorApp/";
    public static String image_url = "https://jaychikki.com/HCA/";
}
