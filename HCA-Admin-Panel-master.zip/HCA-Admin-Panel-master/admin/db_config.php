<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "jaychtac_hca_user");
define("DB_PASSWORD", "HCAuser@2023");
define("DB_DATABASE", "jaychtac_hca");
?>

		